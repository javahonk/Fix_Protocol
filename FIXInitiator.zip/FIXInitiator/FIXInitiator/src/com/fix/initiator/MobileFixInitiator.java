package com.fix.initiator;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.CountDownLatch;

import quickfix.ApplicationAdapter;
import quickfix.ConfigError;
import quickfix.DefaultMessageFactory;
import quickfix.FieldNotFound;
import quickfix.FileStoreFactory;
import quickfix.IncorrectDataFormat;
import quickfix.IncorrectTagValue;
import quickfix.Message;
import quickfix.RejectLogon;
import quickfix.ScreenLogFactory;
import quickfix.Session;
import quickfix.SessionID;
import quickfix.SessionNotFound;
import quickfix.SessionSettings;
import quickfix.SocketInitiator;
import quickfix.UnsupportedMessageType;
import quickfix.field.ClOrdID;
import quickfix.field.ExecType;
import quickfix.field.HandlInst;
import quickfix.field.OrdType;
import quickfix.field.OrderQty;
import quickfix.field.Price;
import quickfix.field.Side;
import quickfix.field.Symbol;
import quickfix.field.TransactTime;
import quickfix.fix42.ExecutionReport;
import quickfix.fix42.NewOrderSingle;

public class MobileFixInitiator extends ApplicationAdapter{
	private SocketInitiator socketInitiator;
	private static final CountDownLatch shutdownLatch = new CountDownLatch(1);
	//private static MobileFixInitiator ;
	private MobileFixInitiator(){
		
	}
	
	public static MobileFixInitiator getInstance() throws ConfigError{
		MobileFixInitiator fixIniator = new MobileFixInitiator();
		SessionSettings sessionSettings = new SessionSettings(
				"./conf/initiator.cfg");
		ApplicationAdapter application = new MobileFixInitiator();
		FileStoreFactory fileStoreFactory = new FileStoreFactory(
				sessionSettings);
		ScreenLogFactory screenLogFactory = new ScreenLogFactory(
				sessionSettings);
		DefaultMessageFactory defaultMessageFactory = new DefaultMessageFactory();
		fixIniator.socketInitiator = new SocketInitiator(application,
				fileStoreFactory, sessionSettings, screenLogFactory,
				defaultMessageFactory);
		fixIniator.socketInitiator.start();
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		return fixIniator;
		 //try { shutdownLatch.await(); } catch (InterruptedException e1){
		 //e1.printStackTrace(); }
	}

	@Override
	public void onLogon(SessionID sessionId) {
		super.onLogon(sessionId);
		System.out.println("Logon initiated");
	}

	@Override
	public void fromAdmin(quickfix.Message message, SessionID sessionId)
			throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue,
			RejectLogon {
		super.fromAdmin(message, sessionId);
	}

	@Override
	public void onCreate(SessionID sessionId) {
		super.onCreate(sessionId);
	}

	@Override
	protected void finalize() throws Throwable {
		super.finalize();
		if (null != this.socketInitiator) {
			this.socketInitiator.stop();
		}
	}

	@Override
	public void fromApp(Message message, SessionID sessionId)
			throws FieldNotFound, IncorrectDataFormat, IncorrectTagValue,
			UnsupportedMessageType {

		if (message instanceof ExecutionReport) {
			ExecutionReport executionReport = (ExecutionReport) message;
			try {
				ExecType executionType = (ExecType) executionReport
						.getExecType();
				System.out.println(executionType);
			} catch (FieldNotFound e) {
				e.printStackTrace();
			}
		}
		System.out.println("Got Execution Report from Exchange \n");
	}
	
	public void sendMobileOrder(String clientOrderID, String symbol, String qty, String price){
		ArrayList<SessionID> sessions = socketInitiator
				.getSessions();
		SessionID sessionID = sessions.get(0);
		NewOrderSingle order = new NewOrderSingle(new ClOrdID(clientOrderID),
				new HandlInst(HandlInst.MANUAL_ORDER), new Symbol(symbol),
				new Side(Side.BUY), new TransactTime(new Date()), new OrdType(
						OrdType.LIMIT));
		order.set(new OrderQty(Integer.parseInt(qty)));
		order.set(new Price(Double.parseDouble(price)));
		try {
			Session.sendToTarget(order, sessionID);
		} catch (SessionNotFound e) {
			e.printStackTrace();
		}
	}
}
